$(document).ready(function () {
	$('.icon-overlay a').prepend('<span class="icn-more"></span>');
});
